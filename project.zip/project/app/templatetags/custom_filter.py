from django import template

register=template.Library()

@register.filter(name='currancy')
def currancy(numbers):
    return "₹"+str(numbers)

@register.filter(name='multiply')
def multiply(numbers,num1):
    return numbers*num1
   