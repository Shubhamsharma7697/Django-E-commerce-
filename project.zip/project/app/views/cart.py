
from django.shortcuts import render
from app.models.product import Product
from django.views import View
# to hide password 

class Cart(View):
    def get(self,request):
        
        # print(list(request.session.get('cart').keys())
        ids=list(request.session.get('cart').keys())
        
        print("ids is:-",ids)
        if ids:
            products=Product.get_products_by_id(ids)
            print(products)
            return render(request,'cart.html',{'products':products})
        else:
            ids={}
            products=Product.get_products_by_id(ids)
            return render(request,'cart.html',{'products':products})

        
