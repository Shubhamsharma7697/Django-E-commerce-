
from django.shortcuts import render,redirect,HttpResponseRedirect

from app.models.customer import Customer
from django.views import View
# to hide password 
from django.contrib.auth.hashers import check_password
class Login(View):
    return_url=None
    def get(self,request):
        Login.return_url=request.GET.get('return_url')
        return render(request,'login.html')
        
    def post(self,request):
        email=request.POST.get('email')
        password=request.POST.get('password')
        user=Customer.get_customer_by_email(email)

        error_message=None
        # print(user)

        if user:
            flag=check_password(password,user.password)
            if flag:
                request.session['user']=user.id

                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                    
                else:
                    Login.return_url=None
                    return redirect("/")


              
                
            else:
                error_message="Password Invalid!!"

        else:
            error_message="Email and Password Invalid!!"

        return render(request,"login.html",{"error":error_message})

        




def logout(request):
    request.session.clear()
    return redirect("login")