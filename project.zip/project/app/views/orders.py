from django.views import View
from django.shortcuts import render
from app.models.orders import Order
from app.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator
class OrderView(View):

    
    def get(self, request):
        customer=request.session.get('user')
        orders=Order.get_orders_by_customer(customer)
        print(orders)
        # print(customer)

        orders=orders.reverse()
        return render(request,"orders.html",{"orders":orders})
       

