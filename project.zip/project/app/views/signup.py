from django.shortcuts import render,redirect
from app.models.customer import Customer
from django.views import View
# to hide password 
from django.contrib.auth.hashers import make_password


class Signup(View):
    def get(self,request):
        return render(request,'signup.html')
    def post(self,request):
        fname=request.POST.get('firstname')
        lname=request.POST.get('lastname')
        email=request.POST.get('email')
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        value={
            'fname':fname,
            'lname':lname,
            'email':email,
            'phone':phone
        }
        # validation  
        error_message=None   
        customer=Customer(fname=fname,
                          lname=lname,
                          phone=phone,
                          email=email,
                          password=password)
        
        error_message=self.validateCustomer(customer)
    #    saving
        if not error_message:
            customer.password=make_password(customer.password)
            customer.save()
            return redirect("/login")
        else:
            data={
            "error":error_message,
            "values":value

            }
            return render(request,"signup.html",data)


    def validateCustomer(self,customer):
        error_message=None
        if(not customer.fname):
            error_message="first Name Required !!"
        elif len(customer.fname)<4:
            error_message="first name must  be 4 character !!"
        elif(not customer.lname):
            error_message="last Name Required !!"
        elif(len(customer.lname)<4):
            error_message="last name must  be 4 character !!"
        elif(not customer.phone):
            error_message="phone number required !!"
        elif(len(customer.phone)<10):
            error_message="phone number must be 10 digit !!"

        elif(len(customer.password)<6):
            error_message="password must be 6 char long !!"
        elif(len(customer.email)<5):
            error_message="Email must be 5 digit !!"

        elif customer.isExist():
            error_message="Email Address Already Registered.."
        

        return error_message





        # print(fname)
        # print(lname)
        # print(phone)
        # print(email)
        # print(password)

        # def register(self):
        #     self.save()
        
        